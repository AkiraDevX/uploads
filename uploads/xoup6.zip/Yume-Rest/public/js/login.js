async function login() {
  const user = document.getElementById("user").value.trim()
  const pass = document.getElementById("pass").value.trim()
  const msg = document.getElementById("msg")
  const btn = document.getElementById("btn")

  msg.textContent = ""

  if (!user || !pass) {
    msg.textContent = "Completa todos los campos"
    return
  }

  btn.disabled = true
  btn.textContent = "Verificando..."

  try {
    const res = await fetch("../login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ user, pass })
    })

    const data = await res.json()

    if (!data.status) {
      msg.textContent = data.message || "Credenciales incorrectas"
      btn.disabled = false
      btn.textContent = "Iniciar sesión"
      return
    }

    // Guardar sesión
    localStorage.setItem("apikey", data.apikey)

    msg.textContent = "Login correcto ✔️"

    setTimeout(() => {
      window.location.href = "/dashboard.html"
    }, 1200)

  } catch (e) {
    msg.textContent = "Error de conexión"
    btn.disabled = false
    btn.textContent = "Iniciar sesión"
  }
}