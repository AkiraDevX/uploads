async function register() {
  const user = document.getElementById("user").value.trim()
  const pass = document.getElementById("pass").value.trim()
  const pass2 = document.getElementById("pass2").value.trim()
  const msg = document.getElementById("msg")
  const btn = document.getElementById("btn")

  msg.textContent = ""

  if (!user || !pass || !pass2) {
    msg.textContent = "Completa todos los campos"
    return
  }

  if (pass.length < 6) {
    msg.textContent = "La contraseña debe tener mínimo 6 caracteres"
    return
  }

  if (pass !== pass2) {
    msg.textContent = "Las contraseñas no coinciden"
    return
  }

  btn.disabled = true
  btn.textContent = "Creando cuenta..."

  try {
    const res = await fetch("../register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ user, pass })
    })

    const data = await res.json()

    if (!data.status) {
      msg.textContent = data.message || "No se pudo crear la cuenta"
      btn.disabled = false
      btn.textContent = "Registrarse"
      return
    }

    msg.textContent = "Cuenta creada ✔️ Redirigiendo..."

    setTimeout(() => {
      window.location.href = "/login.html"
    }, 1500)

  } catch (err) {
    msg.textContent = "Error de conexión"
    btn.disabled = false
    btn.textContent = "Registrarse"
  }
}