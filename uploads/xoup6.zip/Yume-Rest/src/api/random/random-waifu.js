const axios = require("axios");

module.exports = function (app) {
  const SFW_TYPES = ["waifu", "neko", "shinobu", "megumin"];

  // 🔹 Listar tipos disponibles
  app.get("/random/types", (req, res) => {
    res.json({ status: true, types: SFW_TYPES });
  });

  // 🔹 Waifu Random Mejorado (rápido)
  app.get("/random/waifu", async (req, res) => {
    try {
      const type = SFW_TYPES[Math.floor(Math.random() * SFW_TYPES.length)];

      // Solo pedimos la URL, no descargamos la imagen
      const { data } = await axios.get(`https://api.waifu.pics/sfw/${type}`);

      const extension = data.url.split(".").pop().split("?")[0]; // sacar extensión de la URL

      res.json({
        status: true,
        result: {
          name: `waifu_${Date.now()}.${extension}`,
          extension,
          type,
          dl_url: data.url,
        },
        timestamp_ms: Date.now(),
        timestamp_iso: new Date().toISOString(),
      });
    } catch (err) {
      res.status(500).json({ status: false, error: err.message });
    }
  });
};