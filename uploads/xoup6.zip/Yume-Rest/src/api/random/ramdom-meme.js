module.exports = function (app) {
  const axios = require("axios")

  app.get("/random/meme", async (req, res) => {
    try {
      const { data } = await axios.get("https://meme-api.com/gimme", {
        timeout: 10000
      })

      if (!data || !data.url) {
        throw new Error("No se pudo obtener meme")
      }

      res.json({
        status: true,
        result: {
          title: data.title,
          subreddit: data.subreddit,
          author: data.author,
          nsfw: data.nsfw,
          spoiler: data.spoiler,
          image: data.url,
          preview: data.preview || [],
          post_link: data.postLink
        },
        timestamp: Date.now()
      })

    } catch (err) {
      res.status(500).json({
        status: false,
        error: err.message
      })
    }
  })
}