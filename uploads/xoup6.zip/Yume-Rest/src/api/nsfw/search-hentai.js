const axios = require('axios')
const cheerio = require('cheerio')

module.exports = function (app) {

  app.get('/nsfw/hentai-search', async (req, res) => {
    try {
      const { q, limit = 15 } = req.query

      if (!q) {
        return res.status(400).json({
          status: false,
          error: 'Falta el parámetro "q"'
        })
      }

      const url = `https://veohentai.com/?s=${encodeURIComponent(q)}`

      const { data: html } = await axios.get(url, {
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36",
          "Accept":
            "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
          "Accept-Language": "en-US,en;q=0.9",
          "Accept-Encoding": "gzip, deflate, br",
          "Connection": "keep-alive",
          "Referer": "https://veohentai.com/"
        },
        timeout: 20000
      })

      const $ = cheerio.load(html)

      let results = []

      $(".grid a").each((i, el) => {
        if (i >= limit) return false

        const link = $(el).attr("href")
        const title = $(el).find("h2").text().trim()
        const thumbnail = $(el).find("img").attr("src") || null

        if (link && title) {
          results.push({
            title,
            url: link,
            thumbnail
          })
        }
      })

      if (!results.length) {
        return res.json({
          status: false,
          message: "No se encontraron resultados"
        })
      }

      res.json({
        status: true,
        query: q,
        total: results.length,
        results
      })

    } catch (err) {
      res.status(500).json({
        status: false,
        error: err.response?.status || err.message
      })
    }
  })

}