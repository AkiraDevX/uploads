const axios = require("axios")
const cheerio = require("cheerio")

module.exports = function (app) {

  app.get("/nsfw/dow-hentai", async (req, res) => {
    try {
      const { url } = req.query

      if (!url) {
        return res.status(400).json({
          status: false,
          error: 'Falta el parámetro "url"'
        })
      }

      const headers = {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36",
        "Referer": "https://veohentai.com/",
        "Accept-Language": "en-US,en;q=0.9"
      }

      // 🔹 1. Página principal
      const { data: html } = await axios.get(url, { headers })

      const $ = cheerio.load(html)

      const title =
        $("h1").first().text().trim() || "Sin título"

      const views = $("h4").first().text().trim() || null
      const likes = $("#num-like").text().trim() || null
      const dislikes = $("#num-dislike").text().trim() || null

      let iframeSrc = $("iframe").attr("src")

      if (!iframeSrc) {
        return res.status(404).json({
          status: false,
          error: "No se encontró iframe"
        })
      }

      // 🔹 Si viene relativo
      if (iframeSrc.startsWith("/")) {
        iframeSrc = "https://veohentai.com" + iframeSrc
      }

      // 🔹 2. Obtener iframe
      const { data: iframeHtml } = await axios.get(iframeSrc, { headers })

      // 🔹 Buscar base64
      const match = iframeHtml.match(/u=([^"&]+)/)

      if (!match) {
        return res.status(404).json({
          status: false,
          error: "No se encontró link codificado"
        })
      }

      const decoded = Buffer.from(match[1], "base64").toString("utf-8")

      if (!decoded.startsWith("http")) {
        return res.status(500).json({
          status: false,
          error: "Link decodificado inválido"
        })
      }

      res.json({
        status: true,
        title,
        views,
        likes,
        dislikes,
        video: decoded
      })

    } catch (err) {
      res.status(500).json({
        status: false,
        error: err.response?.status || err.message
      })
    }
  })

}