module.exports = function (app) {
  const axios = require('axios')
  const cheerio = require('cheerio')

  app.get('/nsfw/pornhub-search', async (req, res) => {
    try {
      const { q } = req.query

      if (!q) {
        return res.status(400).json({
          status: false,
          error: "Falta el parámetro 'q'"
        })
      }

      const results = await phSearch(q)

      if (!results.length) {
        return res.status(404).json({
          status: false,
          error: 'No se encontraron resultados'
        })
      }

      res.json({
        status: true,
        query: q,
        total: results.length,
        result: results
      })
    } catch (e) {
      res.status(500).json({
        status: false,
        error: e.message
      })
    }
  })

  async function phSearch(query) {
    const url =
      'https://www.pornhub.com/video/search?search=' +
      encodeURIComponent(query)

    const { data: html } = await axios.get(url, {
      timeout: 20000,
      headers: {
        'user-agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/121.0.0.0 Safari/537.36',
        accept:
          'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'accept-language': 'en-US,en;q=0.9',
        referer: 'https://www.pornhub.com/'
      }
    })

    const $ = cheerio.load(html)
    const results = []

    // 🔄 Selectores nuevos
    $('li.videoBox').each((i, el) => {
      const a = $(el).find('a').first()

      let title =
        a.attr('title') ||
        $(el).find('span.title').text().trim()

      let link = a.attr('href')

      const duration = $(el)
        .find('.duration')
        .text()
        .trim()

      const views = $(el)
        .find('.views')
        .text()
        .replace(/\s+/g, ' ')
        .trim()

      const thumb =
        $(el).find('img').attr('data-thumb_url') ||
        $(el).find('img').attr('src')

      if (!title || !link) return

      if (link.startsWith('/')) {
        link = 'https://www.pornhub.com' + link
      }

      results.push({
        no: results.length + 1,
        title,
        duration: duration || null,
        views: views || null,
        thumbnail: thumb || null,
        url: link
      })
    })

    return results
  }
}