const https = require('https')

function getJSON(url) {
  return new Promise((resolve, reject) => {
    https.get(url, res => {
      let data = ''
      res.on('data', c => data += c)
      res.on('end', () => {
        try {
          resolve(JSON.parse(data))
        } catch {
          reject('JSON inválido')
        }
      })
    }).on('error', reject)
  })
}

module.exports = function (app) {
  app.get('/nsfw/pornhub-dl', async (req, res) => {
    const { url } = req.query
    if (!url) return res.json({ status: false })

    try {
      const api =
        `https://api-yume-ol5u.onrender.com/download/pornhub-dl?url=${encodeURIComponent(url)}`

      const data = await getJSON(api)
      res.json({ status: true, data: data.result })

    } catch {
      res.status(500).json({ status: false })
    }
  })
}