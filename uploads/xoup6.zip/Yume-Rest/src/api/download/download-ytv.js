module.exports = function (app) {
  const fs = require('fs')

  const yt = {
    static: Object.freeze({
      baseUrl: 'https://cnv.cx',
      headers: {
        'accept-encoding': 'gzip, deflate, br, zstd',
        'origin': 'https://frame.y2meta-uk.com',
        'user-agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36'
      }
    }),

    resolveConverterPayload(link, f = '720p') {
      const formatos = ['144p', '240p', '360p', '480p', '720p', '1080p']
      if (!formatos.includes(f))
        throw new Error(`Formato inválido (${formatos.join(', ')})`)

      return {
        link,
        format: 'mp4',
        videoQuality: f.replace('p', ''),
        audioBitrate: '128',
        filenameStyle: 'pretty',
        vCodec: 'h264'
      }
    },

    async getKey() {
      const r = await fetch(this.static.baseUrl + '/v2/sanity/key', {
        headers: this.static.headers
      })
      if (!r.ok) throw new Error('Key error')
      return await r.json()
    },

    async convert(url, quality) {
      const { key } = await this.getKey()
      const payload = this.resolveConverterPayload(url, quality)

      const r = await fetch(this.static.baseUrl + '/v2/converter', {
        method: 'POST',
        headers: { ...this.static.headers, key },
        body: new URLSearchParams(payload)
      })

      if (!r.ok) throw new Error('Convert error')
      return await r.json()
    }
  }

  app.get('/download/ytmp4', async (req, res) => {
    try {
      const { url, q = '480p' } = req.query

      if (!url) {
        return res.status(400).json({
          status: false,
          error: 'URL requerida'
        })
      }

      const data = await yt.convert(url, q)

      if (!data?.url) {
        return res.status(502).json({
          status: false,
          error: 'No se pudo generar el video'
        })
      }

      res.json({
        status: true,
        data: {
          title: data.filename,
          quality: q,
          size: data.size,
          dl_url: data.url
        }
      })
    } catch (e) {
      console.error('[YTMP4]', e)
      res.status(500).json({
        status: false,
        error: e.message
      })
    }
  })
}