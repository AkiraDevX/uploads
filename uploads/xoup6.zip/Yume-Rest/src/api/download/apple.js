const axios = require("axios")

module.exports = function (app) {

  async function applemusicdl(url) {
    try {

      // 1 obtener info
      const info = await axios.get(
        `https://api.fabdl.com/apple-music/get?url=${encodeURIComponent(url)}`,
        {
          headers: {
            accept: "application/json, text/plain, */*"
          }
        }
      )

      const data = info.data.result

      if (!data || !data.gid) {
        throw new Error("No se pudo obtener información")
      }

      // 2 generar mp3
      const convert = await axios.get(
        `https://api.fabdl.com/apple-music/mp3-convert-task/${data.gid}/${data.id}`,
        {
          headers: {
            accept: "application/json, text/plain, */*"
          }
        }
      )

      return {
        title: data.name,
        artist: data.artists,
        duration: data.duration_ms,
        image: data.image,
        download: "https://api.fabdl.com" + convert.data.result.download_url
      }

    } catch (err) {
      throw err
    }
  }

  app.get("/download/applemusic1", async (req, res) => {

    try {

      const { url } = req.query

      if (!url) {
        return res.status(400).json({
          status: false,
          error: "url requerida"
        })
      }

      const result = await applemusicdl(url)

      res.json({
        status: true,
        result
      })

    } catch (err) {

      res.status(500).json({
        status: false,
        error: err.message
      })

    }

  })

}