const axios = require("axios")

module.exports = function (app) {

const sleep = ms => new Promise(r => setTimeout(r, ms))

const tools = {

genRandomHex(length=32){
const chars="0123456789abcdef"
let result=""
for(let i=0;i<length;i++){
result+=chars[Math.floor(Math.random()*chars.length)]
}
return result
},

enc1(url){
return url.split("").map(v=>v.charCodeAt()).reverse().join()
},

enc2(url){
return url.split("").map(v=>String.fromCharCode(v.charCodeAt() ^ 1)).join('')
},

validateString(name,value){
if(typeof value !== "string" || !value.trim()){
throw new Error(`${name} inválido`)
}
}

}

const baseHeaders = {
"content-type":"application/json",
"referer":"https://ytmp3.lat/",
"user-agent":"Mozilla/5.0"
}

async function init(url,format){

tools.validateString("youtube url",url)

const formats={
mp3:0,
mp4:1
}

if(formats[format] === undefined){
throw new Error("format invalido")
}

const encUrl = tools.enc1(url)
const encPayload = tools.enc2(url)

const hash1 = tools.genRandomHex()
const hash2 = tools.genRandomHex()

const api = `https://ytmp3.lat/${hash1}/init/${encUrl}/${hash2}/`

const res = await axios.post(api,{
data:encPayload,
format:String(formats[format])
},{
headers:baseHeaders
})

return {
...res.data,
format
}

}

function createDownloadUrl(task){

const hash1 = tools.genRandomHex()
const hash2 = tools.genRandomHex()

const encTask = tools.enc2(task.i)

return `https://ytmp3.lat/${hash1}/download/${encTask}/${hash2}/`

}

async function checkStatus(initData){

let data = initData
let attempts = 0

while(attempts < 60){

if(data.s === "C"){
return {
title:data.t || "unknown",
format:initData.format,
download:createDownloadUrl(data)
}
}

const hash1 = tools.genRandomHex()
const hash2 = tools.genRandomHex()

const url = `https://ytmp3.lat/${hash1}/status/${data.i}/${hash2}/`

const res = await axios.post(url,{
data:data.i
},{
headers:baseHeaders
})

data = res.data

if(data.le) throw new Error("video mayor a 60 minutos")
if(data.e) throw new Error("error convirtiendo")
if(data.i === "invalid") throw new Error("youtube url invalida")

attempts++

await sleep(3000)

}

throw new Error("timeout conversion")

}

async function downloadYoutube(url,format="mp3"){

const initData = await init(url,format)

const result = await checkStatus(initData)

return result

}

app.get("/download/ytmp3", async (req,res)=>{

try{

const { url, format="mp3" } = req.query

if(!url){
return res.json({
status:false,
error:"url requerida"
})
}

const result = await downloadYoutube(url,format)

res.json({
status:true,
result
})

}catch(err){

res.json({
status:false,
error:err.message
})

}

})

}