const { fbdl } = require('../../lib/fbdl')

module.exports = function (app) {

  app.get('/download/facebook', async (req, res) => {
    try {
      const { url } = req.query

      if (!url) {
        return res.status(400).json({
          status: false,
          message: "Falta el parámetro ?url="
        })
      }

      const result = await fbdl(url)

      if (result.error) {
        return res.status(500).json({
          status: false,
          message: result.message
        })
      }

      res.json({
        status: true,
        data: {
          thumbnail: result.thumbnail,
          download: {
            sd: result.video_sd,
            hd: result.video_hd
          }
        }
      })

    } catch (err) {
      res.status(500).json({
        status: false,
        message: err.message
      })
    }
  })

}