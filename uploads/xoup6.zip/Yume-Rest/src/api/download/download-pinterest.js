module.exports = function (app) {

  const axios = require("axios");
  const cheerio = require("cheerio");
  const http = axios.create({
    timeout: 6000,
    maxRedirects: 3,
    headers: {
      "User-Agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
      Accept: "text/html"
    }
  });

  function clean(obj) {
    return Object.fromEntries(
      Object.entries(obj).filter(([_, v]) =>
        v !== null && v !== undefined && v !== ""
      )
    );
  }

  async function expandUrl(url) {
    try {
      const res = await axios.get(url, {
        maxRedirects: 5,
        headers: { "User-Agent": "Mozilla/5.0" }
      });
      return res.request.res.responseUrl || url;
    } catch {
      return url;
    }
  }

  async function downloadPinterest(url) {
    const { data: html } = await http.get(url);
    const $ = cheerio.load(html);

    let title = null;
    let description = null;
    let author = null;
    let username = null;
    let published = null;
    let likes = null;
    let keywords = [];
    let board = null;
    let followers = null;
    let width = null;
    let height = null;

    $('script[type="application/ld+json"]').each((_, el) => {
      try {
        const json = JSON.parse($(el).html());

        if (json.name) title = json.name;
        if (json.description) description = json.description;
        if (json.uploadDate) published = json.uploadDate;
        if (json.author?.name) author = json.author.name;
        if (json.keywords)
          keywords = json.keywords.split(",").map(x => x.trim());

      } catch {}
    });

    // Username
    const userMatch = html.match(/"username":"(.*?)"/);
    if (userMatch) username = userMatch[1];

    // Likes
    const likesMatch = html.match(/"reactionCount":(\d+)/);
    if (likesMatch)
      likes = Number(likesMatch[1]).toLocaleString();

    // Board
    const boardMatch = html.match(/"board":{"id":".*?","name":"(.*?)"/);
    if (boardMatch) board = boardMatch[1];

    // Followers
    const followMatch = html.match(/"follower_count":(\d+)/);
    if (followMatch)
      followers = Number(followMatch[1]).toLocaleString();

    // Dimensiones
    const dimMatch = html.match(/"width":(\d+),"height":(\d+)/);
    if (dimMatch) {
      width = dimMatch[1];
      height = dimMatch[2];
    }

    // vid
    const videoScript = $('script[data-test-id="video-snippet"]').html();
    if (videoScript) {
      try {
        const json = JSON.parse(videoScript);

        if (json.contentUrl) {
          return clean({
            title: title || "Sin título",
            description: description || "Sin descripción",
            author: author || "Desconocido",
            username,
            followers,
            board,
            type: "video",
            likes: likes || "0",
            publicado: published
              ? new Date(published).toLocaleString("en-US")
              : null,
            duration: json.duration || null,
            dimensions: width && height ? `${width}x${height}` : null,
            keywords,
            dl_url: json.contentUrl,
            thumbnail: json.thumbnailUrl || null
          });
        }

      } catch {}
    }

    // IMAGEN / GIF (736x ~ 720p)
    const leafScript = $('script[data-test-id="leaf-snippet"]').html();
    if (leafScript) {
      try {
        const json = JSON.parse(leafScript);

        if (json.image) {

          const hdImage = json.image.replace(/\/\d+x\//, "/736x/");

          return clean({
            title: title || "Sin título",
            description: description || "Sin descripción",
            author: author || "Desconocido",
            username,
            followers,
            board,
            type: hdImage.endsWith(".gif") ? "gif" : "image",
            likes: likes || "0",
            publicado: published
              ? new Date(published).toLocaleString("en-US")
              : null,
            dimensions: width && height ? `${width}x${height}` : null,
            keywords,
            dl_url: hdImage,
            thumbnail: hdImage
          });
        }

      } catch {}
    }

    return null;
  }

  app.get("/download/pindl", async (req, res) => {
    try {

      let { url } = req.query;

      if (!url) {
        return res.status(400).json({
          status: false,
          error: "Missing parameter ?url="
        });
      }

      url = await expandUrl(url);

      const result = await downloadPinterest(url);

      if (!result) {
        return res.status(404).json({
          status: false,
          error: "Content not found"
        });
      }

      return res.json({
        status: true,
        data: result
      });

    } catch (err) {
      return res.status(500).json({
        status: false,
        error: err.message
      });
    }
  });

};