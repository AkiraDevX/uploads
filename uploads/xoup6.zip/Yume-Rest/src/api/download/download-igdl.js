module.exports = function (app) {
  const axios = require('axios')
  const CryptoJS = require('crypto-js')
  const qs = require('qs')
  const cheerio = require('cheerio')

  const BASE_URL = 'https://allinonedownloader.com'
  const LANDING_PAGE = 'https://allinonedownloader.com/in/instagram-video-downloader.php'

  const COMMON_HEADERS = {
    'User-Agent':
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36',
    Accept:
      'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9,id;q=0.8'
  }

  async function scrapeInstagram(url) {
    if (!url) throw new Error('URL requerida')

    // 1️⃣ Obtener landing page (cookie + token)
    const pageResponse = await axios.get(LANDING_PAGE, {
      headers: COMMON_HEADERS
    })

    const rawCookies = pageResponse.headers['set-cookie']
    const cookieString = rawCookies
      ? rawCookies.map(c => c.split(';')[0]).join('; ')
      : ''

    const $ = cheerio.load(pageResponse.data)

    const token = $('#token').val()
    const apiEndpoint = $('#scc').val()
    let jsPath = $('script[src*="main.js"]').attr('src')

    if (!token || !apiEndpoint || !jsPath)
      throw new Error('No se pudo obtener configuración')

    if (!jsPath.startsWith('http')) {
      jsPath = BASE_URL + (jsPath.startsWith('/') ? '' : '/') + jsPath
    }

    // 2️⃣ Obtener IV desde JS
    const jsResponse = await axios.get(jsPath, { headers: COMMON_HEADERS })
    const ivMatch = jsResponse.data.match(
      /var\s+iv\s*=\s*CryptoJS\.enc\.Hex\.parse\(['"]([a-f0-9]+)['"]\)/i
    )

    if (!ivMatch) throw new Error('No se encontró IV')

    const keyHex = CryptoJS.enc.Hex.parse(token)
    const ivHex = CryptoJS.enc.Hex.parse(ivMatch[1])

    const encrypted = CryptoJS.AES.encrypt(url, keyHex, {
      iv: ivHex,
      padding: CryptoJS.pad.ZeroPadding
    })

    const urlHash = encrypted.toString()

    // 3️⃣ POST request final
    const payload = qs.stringify({
      url,
      token,
      urlhash: urlHash
    })

    const fullApiUrl = apiEndpoint.startsWith('http')
      ? apiEndpoint
      : BASE_URL + apiEndpoint

    const apiResponse = await axios.post(fullApiUrl, payload, {
      headers: {
        ...COMMON_HEADERS,
        'Content-Type':
          'application/x-www-form-urlencoded; charset=UTF-8',
        Origin: BASE_URL,
        Referer: LANDING_PAGE,
        'X-Requested-With': 'XMLHttpRequest',
        Cookie: cookieString
      }
    })

    const data = apiResponse.data

    if (data === 'sessionexpired')
      throw new Error('Sesión expirada')

    if (!data.links || !data.links.length)
      throw new Error('No se encontró contenido o es privado')

    return {
      title: data.title || null,
      thumbnail: data.thumbnail || null,
      duration: data.duration || null,
      medias: data.links.map(link => ({
        quality: link.quality,
        format: link.type,
        size: link.size,
        url: link.url,
        mute: link.mute
      }))
    }
  }

  app.get('/download/igdl', async (req, res) => {
    try {
      const { url } = req.query

      if (!url) {
        return res.status(400).json({
          status: false,
          message: 'Falta el parámetro ?url='
        })
      }

      if (!/instagram\.com/.test(url)) {
        return res.status(400).json({
          status: false,
          message: 'URL inválida'
        })
      }

      const result = await scrapeInstagram(url)

      return res.json({
        status: true,
        data: result
      })
    } catch (err) {
      return res.status(500).json({
        status: false,
        message: err.message || 'Error interno'
      })
    }
  })
}