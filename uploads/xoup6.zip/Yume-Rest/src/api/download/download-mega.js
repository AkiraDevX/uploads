const { File } = require("megajs")

module.exports = function (app) {
  app.get("/download/mega", async (req, res) => {
    try {
      const { url } = req.query

      if (!url) {
        return res.status(400).json({
          status: false,
          error: "Falta el parámetro ?url="
        })
      }

      const file = File.fromURL(url)
      await file.loadAttributes()

      const bytes = file.size
      const mb = +(bytes / 1024 / 1024).toFixed(2)
      const kb = +(bytes / 1024).toFixed(2)

      res.json({
        status: true,
        data: {
          title: file.name,
          size: mb + " MB",
          dl_url: url
        }
      })
    } catch (err) {
      console.error("[MEGA-ENDPOINT]", err.message)
      res.status(500).json({
        status: false,
        error: err.message
      })
    }
  })
}