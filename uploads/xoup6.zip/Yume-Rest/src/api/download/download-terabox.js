module.exports = function (app) {

  const { fetch } = require("undici")

  const headers = {
    "User-Agent":
      "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
    "Accept": "application/json, text/plain, */*",
    "Content-Type": "application/json",
    "Origin": "https://teraboxdl.site",
    "Referer": "https://teraboxdl.site/",
    "X-Requested-With": "XMLHttpRequest"
  }

  async function teraboxdl(link) {

    const r = await fetch("https://teraboxdl.site/api/proxy", {
      method: "POST",
      headers,
      body: JSON.stringify({
        link
      })
    })

    if (!r.ok) {
      throw new Error(`HTTP ${r.status}`)
    }

    return await r.json()
  }

  app.get("/download/terabox", async (req, res) => {

    try {

      const { url } = req.query

      if (!url) {
        return res.status(400).json({
          status: false,
          error: "Falta parámetro ?url="
        })
      }

      const data = await teraboxdl(url)

      res.json({
        status: true,
        data
      })

    } catch (err) {

      console.error("[TERABOX]", err.message)

      res.status(500).json({
        status: false,
        error: err.message
      })

    }

  })

}