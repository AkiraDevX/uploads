const axios = require("axios")
const crypto = require("crypto")

class SaveTube {
  constructor() {
    this.ky = "C5D58EF67A7584E4A29F6C35BBC4EB12"
    this.m =
      /^((?:https?:)?\/\/)?((?:www|m|music)\.)?(?:youtube\.com|youtu\.be)\/(?:watch\?v=)?(?:embed\/)?(?:v\/)?(?:shorts\/)?([a-zA-Z0-9_-]{11})/

    this.is = axios.create({
      headers: {
        "content-type": "application/json",
        origin: "https://yt.savetube.me",
        "user-agent":
          "Mozilla/5.0 (Android 15; Mobile; SM-F958; rv:130.0) Gecko/130.0 Firefox/130.0"
      }
    })
  }

  async decrypt(enc) {
    const sr = Buffer.from(enc, "base64")
    const ky = Buffer.from(this.ky, "hex")

    const iv = sr.slice(0, 16)
    const dt = sr.slice(16)

    const dc = crypto.createDecipheriv("aes-128-cbc", ky, iv)

    return JSON.parse(Buffer.concat([dc.update(dt), dc.final()]).toString())
  }

  async getCdn() {
    const r = await this.is.get(
      "https://media.savetube.vip/api/random-cdn"
    )
    return r.data.cdn
  }

  async download(url, type = "audio", quality = "128") {
    const id = url.match(this.m)?.[3]
    if (!id) throw new Error("ID inválido")

    const cdn = await this.getCdn()

    const info = await this.is.post(`https://${cdn}/v2/info`, {
      url: `https://www.youtube.com/watch?v=${id}`
    })

    const dec = await this.decrypt(info.data.data)

    const dl = await this.is.post(`https://${cdn}/download`, {
      id,
      downloadType: type,
      quality,
      key: dec.key
    })

    return {
      title: dec.title,
      duration: dec.duration,
      thumbnail: dec.thumbnail,
      download: dl.data.data.downloadUrl
    }
  }
}

module.exports = function (app) {
  const sv = new SaveTube()

  app.get("/download/savetube", async (req, res) => {
    try {
      const { url, type, quality } = req.query

      if (!url) {
        return res.json({
          status: false,
          error: "url requerida"
        })
      }

      const t = type === "video" ? "video" : "audio"
      const q = quality || (t === "audio" ? "128" : "720")

      const data = await sv.download(url, t, q)

      res.json({
        status: true,
        data: {
          type: t,
          quality: q,
          title: data.title,
          duration: data.duration,
          thumbnail: data.thumbnail,
          url: data.download
        }
      })
    } catch (e) {
      res.json({
        status: false,
        error: e.message
      })
    }
  })
}