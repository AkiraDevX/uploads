module.exports = function (app) {
  const axios = require("axios")
  const { searchAnime } = require("../../lib/anime")

  app.get("/anime/search/kompi", async (req, res) => {
    try {
      const { q } = req.query

      if (!q) {
        return res.status(400).json({
          status: false,
          error: "Falta el parámetro 'q'"
        })
      }

      const results = await searchAnime(q)

      res.json({
        status: true,
        query: q,
        total: results.length,
        results
      })

    } catch (e) {
      res.status(500).json({
        status: false,
        error: e.message
      })
    }
  })
}