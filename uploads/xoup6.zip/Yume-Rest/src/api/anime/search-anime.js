module.exports = function (app) {
  const fetch = require("node-fetch");
  const cheerio = require("cheerio");

  app.get("/anime/search/animeav1", async (req, res) => {
    try {
      const { q } = req.query;
      if (!q) {
        return res.status(400).json({
          status: false,
          error: "Falta el parámetro ?q="
        });
      }

      const base = "https://animeav1.com";
      const url = `${base}/catalogo?search=${encodeURIComponent(q)}`;

      const r = await fetch(url, {
        headers: {
          "User-Agent": "Mozilla/5.0"
        }
      });

      const html = await r.text();
      const $ = cheerio.load(html);

      const results = [];

      $("article").each((_, el) => {
        const title = $(el).find("h3").text().trim();
        const link = base + $(el).find("a").attr("href");
        const image = $(el).find("img").attr("src");

        if (title && link) {
          results.push({
            type: "anime",
            title,
            image,
            link
          });
        }
      });

      res.json({
        status: true,
        source: "animeav1",
        total: results.length,
        results
      });

    } catch (e) {
      res.status(500).json({
        status: false,
        error: "Error al buscar anime",
        message: e.message
      });
    }
  });
};