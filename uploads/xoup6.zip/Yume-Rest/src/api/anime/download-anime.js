module.exports = function (app) {
  const axios = require("axios");
  const cheerio = require("cheerio");

  app.get("/anime/download/animeav1", async (req, res) => {
    try {
      const { url } = req.query;
      if (!url) {
        return res.status(400).json({
          status: false,
          error: "Falta el parámetro ?url="
        });
      }

      const base = "https://animeav1.com";

      const { data: html } = await axios.get(url, {
        headers: {
          "User-Agent": "Mozilla/5.0"
        }
      });

      const $ = cheerio.load(html);

      const title = $("h1").first().text().trim();
      const altTitle = $("h2").first().text().trim();
      const description = $(".entry p").text().trim();
      const rating = $(".ic-star-solid .text-2xl").first().text().trim();
      const votes = $(".ic-star-solid .text-xs span").first().text().trim();

      const cover = $('figure img[alt$="Poster"]').attr("src");
      const backdrop = $('figure img[alt$="Backdrop"]').attr("src");

      const genres = [];
      $('a.btn[href*="catalogo?genre="]').each((_, el) => {
        genres.push($(el).text().trim());
      });

      const globalDubs = [];
      $('.badge, .tag, span, button').each((_, el) => {
        const t = $(el).text().trim().toLowerCase();
        if (t.includes("sub")) globalDubs.push("SUB");
        if (t.includes("dub")) globalDubs.push("DUB");
        if (t.includes("lat")) globalDubs.push("LATINO");
        if (t.includes("cast")) globalDubs.push("CASTELLANO");
      });

      const availableGlobalDubs = [...new Set(globalDubs)];

      // 📺 Episodios + doblaje por episodio
      const episodes = [];

      $('article.group\\/item').each((_, el) => {
        const ep = $(el);
        const dubs = [];

        ep.find('.badge, .tag, span, button').each((_, tag) => {
          const text = $(tag).text().trim().toLowerCase();

          if (text.includes("sub")) dubs.push("SUB");
          if (text.includes("dub")) dubs.push("DUB");
          if (text.includes("lat")) dubs.push("LATINO");
          if (text.includes("cast")) dubs.push("CASTELLANO");
        });

        episodes.push({
          episode: ep.find(".text-lead").first().text().trim(),
          download_url: base + ep.find("a").attr("href"),
          available_dubs: dubs.length ? [...new Set(dubs)] : ["SUB"]
        });
      });

      res.json({
        status: true,
        info: {
          title: `${title} - ${altTitle || "N/A"}`,
          description: description || "Sin descripción",
          rating: rating || "N/A",
          votes: votes || "N/A",
          genres,
          cover,
          backdrop,
          available_dubs: availableGlobalDubs.length
            ? availableGlobalDubs
            : ["SUB"]
        },
        episodes
      });

    } catch (e) {
      res.status(500).json({
        status: false,
        error: "Error al obtener información del anime",
        message: e.message
      });
    }
  });
};