module.exports = function (app) {
  const {
    getHome,
    getDetail,
    getStream
  } = require('../../lib/anime.js')

  app.get('/anime/download/kompi', async (req, res) => {
    try {
      const { url } = req.query

      if (!url) {
        return res.status(400).json({
          status: false,
          error: "Falta el parámetro 'url'"
        })
      }

      let result
      let type

      // ▶️ STREAM / DOWNLOAD
      if (/episode-/i.test(url)) {
        type = 'stream'
        result = await getStream(url)
      }

      // 📄 DETAIL ANIME
      else if (/\/anime\//i.test(url)) {
        type = 'detail'
        result = await getDetail(url)
      }

      // 🏠 HOME
      else if (/animekompi\.fun\/?$/i.test(url)) {
        type = 'home'
        result = await getHome(1)
      }

      else {
        return res.status(400).json({
          status: false,
          error: 'URL no soportada'
        })
      }

      res.json({
        status: true,
        result
      })

    } catch (err) {
      res.status(500).json({
        status: false,
        error: err.message
      })
    }
  })
}