module.exports = function (app) {
  const fetch = require("node-fetch");
  const cheerio = require("cheerio");

  app.get("/search/hentai", async (req, res) => {
    try {
      const { q } = req.query;
      if (!q) {
        return res.json({
          status: false,
          error: "Falta ?q="
        });
      }

      const r = await fetch(`https://veohentai.com/?s=${encodeURIComponent(q)}`, {
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36",
          "Accept":
            "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
          "Accept-Language": "es-ES,es;q=0.9",
          "Referer": "https://veohentai.com/",
          "Connection": "keep-alive",
          "Cache-Control": "no-cache"
        }
      });

      const html = await r.text();
      const $ = cheerio.load(html);

      let results = [];

      $("article.item").each((_, el) => {
        const title = $(el).find("h2").text().trim();
        const link = $(el).find("a").attr("href");
        const thumbnail =
          $(el).find("img").attr("data-src") ||
          $(el).find("img").attr("src");

        if (title && link) {
          results.push({ title, link, thumbnail });
        }
      });

      res.json({
        status: true,
        total: results.length,
        results
      });

    } catch (e) {
      res.json({
        status: false,
        error: e.message
      });
    }
  });
};