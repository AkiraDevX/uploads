module.exports = function (app) {
  const axios = require("axios");

  const SPOTIFY_CLIENT_ID = "acc6302297e040aeb6e4ac1fbdfd62c3";
  const SPOTIFY_CLIENT_SECRET = "0e8439a1280a43aba9a5bc0a16f3f009";


  let spotifyToken = null;
  let tokenExpire = 0;

  const spotifyAuth = axios.create({
    baseURL: "https://accounts.spotify.com",
    timeout: 8000
  });

  const spotifyAPI = axios.create({
    baseURL: "https://api.spotify.com",
    timeout: 8000
  });

  // ================= TOKEN =================
  async function getSpotifyToken() {
    if (spotifyToken && Date.now() < tokenExpire) return spotifyToken;

    const auth = Buffer.from(
      `${SPOTIFY_CLIENT_ID}:${SPOTIFY_CLIENT_SECRET}`
    ).toString("base64");

    const { data } = await spotifyAuth.post(
      "/api/token",
      "grant_type=client_credentials",
      {
        headers: {
          Authorization: `Basic ${auth}`,
          "Content-Type": "application/x-www-form-urlencoded"
        }
      }
    );

    spotifyToken = data.access_token;
    tokenExpire = Date.now() + (data.expires_in - 60) * 1000;

    return spotifyToken;
  }

  // ================= ROUTE =================
  app.get("/search/spotify", async (req, res) => {
    try {
      const { q, limit } = req.query;

      if (!q) {
        return res.status(400).json({
          status: false,
          error: "Falta el parámetro ?q="
        });
      }

      const max = Math.min(Number(limit) || 20, 50);

      let token = await getSpotifyToken();

      let response;

      try {
        response = await spotifyAPI.get("/v1/search", {
          params: {
            q,
            type: "track",
            limit: max
          },
          headers: {
            Authorization: `Bearer ${token}`
          }
        });
      } catch (err) {
        // renovar token si expiró
        if (err.response?.status === 401) {
          spotifyToken = null;
          token = await getSpotifyToken();

          response = await spotifyAPI.get("/v1/search", {
            params: {
              q,
              type: "track",
              limit: max
            },
            headers: {
              Authorization: `Bearer ${token}`
            }
          });
        } else {
          throw err;
        }
      }

      const data = response.data;

      if (!data?.tracks?.items) {
        return res.status(502).json({
          status: false,
          error: "Respuesta inválida de Spotify"
        });
      }

      const results = data.tracks.items.map(track => ({
        id: track.id,
        tipo: track.type,
        tipo_album: track.album.album_type,
        title: track.name,
        artist: track.artists.map(a => a.name).join(", "),
        autor: track.artists[0]?.name || null,
        album: track.album.name,
        publicado: track.album.release_date,
        popularidad: track.popularity + "%",
        duration: `${Math.floor(track.duration_ms / 60000)}:${Math.floor(
          (track.duration_ms % 60000) / 1000
        ).toString().padStart(2, "0")}`,
        thumbnail: track.album.images?.[0]?.url,
        spotify_url: track.external_urls.spotify
      }));

      res.json({
        status: true,
        query: q,
        total: results.length,
        results
      });

    } catch (err) {
      console.error("[SPOTIFY SEARCH]", err.message);

      res.status(500).json({
        status: false,
        error: "Error al buscar en Spotify"
      });
    }
  });
};