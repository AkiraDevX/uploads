module.exports = function (app) {
  const axios = require("axios")

  app.get("/search/google-image", async (req, res) => {
    try {
      const { q, limit = 10 } = req.query

      if (!q) {
        return res.status(400).json({
          status: false,
          error: "Falta el parámetro ?q="
        })
      }

      const max = Number(limit) || 10
      const url = `https://www.google.com/search?q=${encodeURIComponent(q)}&tbm=isch&hl=en`

      const { data: html } = await axios.get(url, {
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
          "Accept-Language": "en-US,en;q=0.9"
        }
      })

      // 🔥 Regex para sacar URLs reales
      const images = []
      const regex = /\["(https:\/\/[^"]+\.(jpg|jpeg|png|webp))"/g

      let match
      while ((match = regex.exec(html)) !== null) {
        const img = match[1]
        if (!images.includes(img)) images.push(img)
        if (images.length >= max) break
      }

      res.json({
        status: true,
        query: q,
        count: images.length,
        results: images.map(url => ({
          image: url
        })),
        timestamp: Date.now()
      })

    } catch (err) {
      res.status(500).json({
        status: false,
        error: err.message
      })
    }
  })
}