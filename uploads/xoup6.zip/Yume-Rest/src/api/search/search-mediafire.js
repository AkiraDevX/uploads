const axios = require("axios");

const SERPAPI_KEY = process.env.SERPAPI_KEY || "tu_api_key_aqui";

async function searchSerpAPI(query, limit) {
  try {
    const { data } = await axios.get("https://serpapi.com/search", {
      params: {
        q: `${query} site:mediafire.com`,
        engine: "google",
        api_key: SERPAPI_KEY,
        num: limit,
        gl: "es"
      },
      timeout: 15000
    });

    if (!data.organic_results) return [];

    return data.organic_results
      .filter(r => r.link && r.link.includes("mediafire.com") && !r.link.includes("/folder/"))
      .slice(0, limit)
      .map(r => ({
        title: r.title || "Unknown",
        url: r.link
      }));

  } catch (err) {
    console.error('SerpAPI error:', err.message);
    return [];
  }
}

module.exports = function (app) {
  app.get("/search/mediafire", async (req, res) => {
    try {
      const { q, limit = 5 } = req.query;

      if (!q) {
        return res.status(400).json({
          status: false,
          error: "Missing parameter ?q="
        });
      }

      if (!SERPAPI_KEY || SERPAPI_KEY === "tu_api_key_aqui") {
        return res.status(400).json({
          status: false,
          error: "SerpAPI key not configured"
        });
      }

      const parsedLimit = Math.min(Number(limit), 10);
      const results = await searchSerpAPI(q, parsedLimit);

      res.json({
        status: results.length > 0,
        query: q,
        total: results.length,
        results
      });

    } catch (err) {
      console.error('Endpoint error:', err.message);
      res.status(500).json({
        status: false,
        error: err.message
      });
    }
  });
};