const cheerio = require("cheerio")
const { fetch, Agent } = require("undici")

module.exports = function (app) {

  async function carigroup(query, groupNo = 0) {

    const slug = query.trim().replace(/\s+/g, "-")

    const res = await fetch(
      `https://groupsor.link/group/searchmore/${encodeURIComponent(slug)}`,
      {
        method: "POST",
        body: new URLSearchParams({
          group_no: String(groupNo)
        }),
        headers: {
          "accept": "*/*",
          "accept-language": "en-US,en;q=0.9",
          "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
          "origin": "https://groupsor.link",
          "referer": `https://groupsor.link/group/search?keyword=${encodeURIComponent(query)}`,
          "x-requested-with": "XMLHttpRequest",
          "user-agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36"
        },
        dispatcher: new Agent({
          connect: { rejectUnauthorized: false }
        })
      }
    )

    if (!res.ok) throw new Error(`HTTP ${res.status}`)

    const html = await res.text()
    const $ = cheerio.load(html)

    const groups = []

    $("#results .maindiv, .maindiv").each((_, element) => {

      const mainDiv = $(element)

      const inviteHref = mainDiv
        .find('a[href*="/group/invite/"]')
        .first()
        .attr("href")

      if (!inviteHref) return

      const name =
        mainDiv.find("img.image").attr("alt")?.trim() || null

      const image =
        mainDiv.find("img.image").attr("src") || null

      const category =
        mainDiv
          .find('a[href*="/group/category/"]')
          .first()
          .text()
          .trim() || null

      const country =
        mainDiv
          .find('a[href*="/group/country/"]')
          .first()
          .text()
          .trim() || null

      let description =
        mainDiv
          .find("p.descri")
          .first()
          .text()
          .trim() || ""

      description = description.replace(
        /\s*\.\.\.\s*continue reading$/i,
        ""
      )

      groups.push({
        name,
        link: inviteHref.replace(
          /^https?:\/\/groupsor\.link\/group\/invite\//,
          "https://chat.whatsapp.com/"
        ),
        image,
        category,
        country,
        description
      })

    })

    return groups
  }

  app.get("/search/wagroup", async (req, res) => {

    try {

      const { q, page = 0 } = req.query

      if (!q) {
        return res.status(400).json({
          status: false,
          error: "Falta parámetro ?q="
        })
      }

      const results = await carigroup(q, page)

      res.json({
        status: true,
        query: q,
        page: Number(page),
        total: results.length,
        results
      })

    } catch (err) {

      console.error(err)

      res.status(500).json({
        status: false,
        error: err.message
      })

    }

  })

}