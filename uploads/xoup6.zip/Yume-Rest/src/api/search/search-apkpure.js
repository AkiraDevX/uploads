const { fetch, Agent } = require("undici");

module.exports = function (app) {

  app.get("/search/apkpure", async (req, res) => {
    try {

      const { q } = req.query;

      if (!q) {
        return res.status(400).json({
          status: false,
          error: "Query requerida"
        });
      }

      const url = `https://apkcombo.com/api/search?q=${encodeURIComponent(q)}`;

      const response = await fetch(url, {
        headers: {
          "accept": "application/json",
          "user-agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36",
          "referer": "https://apkcombo.com/",
          "origin": "https://apkcombo.com"
        },
        dispatcher: new Agent({
          connect: { rejectUnauthorized: false }
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const data = await response.json();

      const results = data.results?.map(app => ({
        title: app.name,
        developer: app.developer,
        link: "https://apkcombo.com" + app.url,
        icon: app.icon
      })) || [];

      res.json({
        status: true,
        total: results.length,
        source: "apkcombo",
        data: results
      });

    } catch (err) {

      console.error("[APK SEARCH]", err.message);

      res.status(500).json({
        status: false,
        error: err.message
      });

    }
  });

};