const { createCanvas, GlobalFonts } = require("@napi-rs/canvas")
const fs = require("fs")
const path = require("path")
const crypto = require("crypto")
const { spawn } = require("child_process")
const { promisify } = require("util")

const writeFileAsync = promisify(fs.writeFile)

module.exports = function (app) {

  app.get("/canvas/attp", async (req, res) => {
    let tempDir = ""
    let frameFiles = []

    try {
      const { text } = req.query

      if (!text)
        return res.status(400).json({
          status: false,
          message: "Falta el parámetro 'text'"
        })

      const width = 400
      const height = 400
      const frames = 30
      const duration = 3
      const fps = frames / duration

      const fontPath = path.join(
        process.cwd(),
        "src",
        "services",
        "canvas",
        "font",
        "LEMONMILK-Bold.otf"
      )

      if (!fs.existsSync(fontPath))
        return res.status(500).json({
          status: false,
          message: "xd"
        })

      GlobalFonts.registerFromPath(fontPath, "LEMONMILK")

      const colors = [
        "#FF0000","#00FF00","#0000FF","#FFFF00","#00FFFF",
        "#FF00FF","#FFA500","#800080","#008080","#FFC0CB",
        "#FFD700","#00BFFF","#8A2BE2","#FF69B4","#B22222"
      ]

      tempDir = path.join(process.cwd(), "files", crypto.randomBytes(8).toString("hex"))
      fs.mkdirSync(tempDir, { recursive: true })

      for (let i = 0; i < frames; i++) {
        const canvas = createCanvas(width, height)
        const ctx = canvas.getContext("2d")

        ctx.fillStyle = "#000"
        ctx.fillRect(0, 0, width, height)

        ctx.fillStyle = colors[i % colors.length]
        ctx.font = "bold 48px LEMONMILK"
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"

        const words = text.split(" ")
        let line = ""
        let lines = []

        for (let n = 0; n < words.length; n++) {
          const testLine = line + words[n] + " "
          if (ctx.measureText(testLine).width > width - 40 && n > 0) {
            lines.push(line.trim())
            line = words[n] + " "
          } else {
            line = testLine
          }
        }
        lines.push(line.trim())

        let y = height / 2 - ((lines.length - 1) * 48) / 2

        ctx.strokeStyle = "#000"
        ctx.lineWidth = 3

        lines.forEach(l => {
          ctx.strokeText(l, width / 2, y)
          ctx.fillText(l, width / 2, y)
          y += 48
        })

        const framePath = path.join(
          tempDir,
          `frame_${String(i).padStart(4, "0")}.png`
        )

        await writeFileAsync(framePath, canvas.toBuffer("image/png"))
        frameFiles.push(framePath)
      }

      const outputFile = crypto.randomBytes(16).toString("hex") + ".mp4"
      const outputPath = path.join(process.cwd(), "files", outputFile)

      const ffmpegArgs = [
        "-y",
        "-framerate", fps.toString(),
        "-i", path.join(tempDir, "frame_%04d.png"),
        "-c:v", "libx264",
        "-pix_fmt", "yuv420p",
        "-preset", "fast",
        outputPath
      ]

      const ffmpeg = spawn("ffmpeg", ffmpegArgs)

      ffmpeg.on("close", code => {
        frameFiles.forEach(f => fs.existsSync(f) && fs.unlinkSync(f))
        fs.existsSync(tempDir) && fs.rmSync(tempDir, { recursive: true, force: true })

        if (code !== 0)
          return res.status(500).json({
            status: false,
            message: "FFmpeg falló"
          })

        res.json({
          status: true,
          result: {
            url: `${req.protocol}://${req.get("host")}/files/${outputFile}`,
            filename: outputFile,
            mimetype: "video/mp4"
          }
        })
      })

    } catch (err) {
      if (tempDir && fs.existsSync(tempDir))
        fs.rmSync(tempDir, { recursive: true, force: true })

      res.status(500).json({
        status: false,
        error: err.message
      })
    }
  })

}