module.exports = function (app) {
  const axios = require("axios")
  const cheerio = require("cheerio")

  app.get("/stalk/instagram", async (req, res) => {
    try {
      let { user } = req.query

      if (!user) {
        return res.status(400).json({
          status: false,
          error: "Falta el parámetro ?user="
        })
      }

      user = user.replace(/^@/, '')
      const url = `https://dumpor.com/v/${user}`

      const { data: html } = await axios.get(url, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
          "Accept-Language": "en-US,en;q=0.9"
        },
        timeout: 15000
      })

      const $ = cheerio.load(html)

      // info principal
      const name = $('div.user__title > a > h1').text().trim()
      const username = $('div.user__title > h4').text().trim()
      const bio = $('div.user__info-desc').text().trim()

      // avatar (Dumpor usa background-image)
      const avatar =
        $('div.user__img')
          .attr('style')
          ?.replace(/background-image:\s*url\(['"](.+?)['"]\);?/, '$1') || null

      // stats numéricos
      const list = $('ul.list > li.list__item')
      const posts = parseInt(list.eq(0).text().replace(/\D/g, ''), 10) || 0
      const followers = parseInt(list.eq(1).text().replace(/\D/g, ''), 10) || 0
      const following = parseInt(list.eq(2).text().replace(/\D/g, ''), 10) || 0

      // stats human readable (1.2K, 3.4M, etc)
      const row = $('#user-page a')
      const postsH = row.eq(0).text().replace(/Posts/i, '').trim()
      const followersH = row.eq(2).text().replace(/Followers/i, '').trim()
      const followingH = row.eq(3).text().replace(/Following/i, '').trim()

      // últimos posts (thumbnails)
      const postsMedia = []
      $('div.content__img-wrap img').each((i, el) => {
        if (i >= 9) return false
        const img = $(el).attr('src')
        if (img) postsMedia.push({ image: img })
      })

      res.json({
        status: true,
        result: {
          name,
          username,
          bio,
          avatar,
          stats: {
            posts,
            followers,
            following,
            postsH,
            followersH,
            followingH
          },
          posts: postsMedia
        },
        timestamp: Date.now()
      })

    } catch (err) {
      res.status(500).json({
        status: false,
        error: "Usuario no encontrado o perfil privado"
      })
    }
  })
}