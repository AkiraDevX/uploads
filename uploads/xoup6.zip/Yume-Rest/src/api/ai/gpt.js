const GptService = require("../../lib/gptService")

module.exports = function (app) {

  app.post("/ai/gpt-4", async (req, res) => {
    try {
      const { text, prompt } = req.body

      if (!text || typeof text !== "string") {
        return res.status(400).json({
          status: false,
          error: "El parámetro 'text' es obligatorio"
        })
      }

      const result = await GptService.process(text, {
        prompt: prompt || null,
        temperature: 1.0
      })

      res.json({
        status: true,
        result
      })

    } catch (err) {
      res.status(500).json({
        status: false,
        error: err.message
      })
    }
  })

}