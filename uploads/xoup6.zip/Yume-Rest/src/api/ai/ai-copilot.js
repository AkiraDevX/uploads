module.exports = function (app) {
  const axios = require("axios");

  app.get("/ai/copilot", async (req, res) => {
    try {
      const { text } = req.query;

      if (!text) {
        return res.status(400).json({
          status: false,
          error: "Falta parámetro ?text=",
        });
      }

      const response = await axios.get(
        "https://api.yupra.my.id/api/ai/copilot",
        {
          params: { text }
        }
      );

      res.json({
        status: true,
        data: {
          result: response.data.result
        }
      });
    } catch (err) {
      res.status(500).json({
        status: false,
        error: err.message,
      });
    }
  });
};