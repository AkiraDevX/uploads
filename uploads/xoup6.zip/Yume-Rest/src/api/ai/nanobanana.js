const axios = require('axios')
const crypto = require('crypto')
const fs = require('fs')
const FormData = require('form-data')
const path = require('path')

module.exports = function (app) {

  app.get('/ai/nanobanana', async (req, res) => {
    try {
      const { url, prompt } = req.query

      if (!url || !prompt) {
        return res.status(400).json({
          status: false,
          error: 'Parámetros requeridos: url y prompt'
        })
      }

      const nanana = new Nanana()

      // 🔥 1. LOGIN COMPLETO
      await nanana.initialize()

      // 🔥 2. Descargar imagen
      const tempPath = path.join(__dirname, `temp_${Date.now()}.png`)

      const img = await axios({
        url,
        method: 'GET',
        responseType: 'stream'
      })

      const writer = fs.createWriteStream(tempPath)
      img.data.pipe(writer)

      await new Promise((resolve, reject) => {
        writer.on('finish', resolve)
        writer.on('error', reject)
      })

      // 🔥 3. Subir imagen
      const upload = await nanana.uploadImage(tempPath)

      // 🔥 4. Generar imagen
      const generate = await nanana.generateImage(upload.url, prompt)

      // 🔥 5. Esperar resultado
      let result
      for (let i = 0; i < 60; i++) { // máximo 120 segundos
        result = await nanana.getResult(generate.request_id)

        if (result.completed) break

        await new Promise(r => setTimeout(r, 2000))
      }

      fs.unlinkSync(tempPath)

      if (!result?.completed) {
        return res.status(500).json({
          status: false,
          error: 'Tiempo de espera agotado'
        })
      }

      res.json({
        status: true,
        prompt,
        result
      })

    } catch (err) {
      res.status(500).json({
        status: false,
        error: err.response?.data || err.message
      })
    }
  })

}