const { ChatGpt } = require("../../lib/chatgpt")

module.exports = function (app) {

  app.get("/ai/chatgpt", async (req, res) => {
    try {

      const { text, web } = req.query

      if (!text) {
        return res.status(400).json({
          status: false,
          error: "Falta parámetro ?text="
        })
      }

      const chat = new ChatGpt()

      const result = await chat.startConversation(
        text,
        web === "true",
        false
      )

      res.json({
        status: true,
        data: {
          response: result.msg
        }
      })

    } catch (err) {

      console.error("[CHATGPT]", err)

      res.status(500).json({
        status: false,
        error: err.message
      })

    }
  })

}