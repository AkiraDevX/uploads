const axios = require('axios')

class NoteGPTChat {
  constructor() {
    this.streamUrl = 'https://notegpt.io/api/v2/chat/stream'
    this.conversationId = this.makeId()
    this.cookie = this.makeCookie()

    this.headers = {
      'authority': 'notegpt.io',
      'accept': '*/*',
      'content-type': 'application/json',
      'origin': 'https://notegpt.io',
      'referer': 'https://notegpt.io/ai-chat',
      'user-agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      'cookie': this.cookie
    }
  }

  makeId() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = Math.random() * 16 | 0
      const v = c === 'x' ? r : (r & 0x3 | 0x8)
      return v.toString(16)
    })
  }

  makeCookie() {
    const anonId = this.makeId()
    const now = Math.floor(Date.now() / 1000)
    const gid = `GA1.2.${Math.floor(Math.random() * 1e9)}.${now}`
    const ga = `GA1.2.${Math.floor(Math.random() * 1e9)}.${now - 2592000}`

    return `anonymous_user_id=${anonId}; _gid=${gid}; _ga=${ga}`
  }

  async chat(text) {
    const payload = {
      message: text,
      language: 'es',
      model: 'gpt-4.1-mini',
      tone: 'default',
      length: 'moderate',
      conversation_id: this.conversationId
    }

    const res = await axios.post(this.streamUrl, payload, {
      headers: this.headers
    })

    const lines = res.data.split('\n')
    const output = []

    for (const line of lines) {
      if (line.startsWith('data: ')) {
        try {
          const json = JSON.parse(line.slice(6))
          if (json.text) output.push(json.text)
        } catch {}
      }
    }

    return output.join('')
  }
}

module.exports = function (app) {
  app.get('/ai/notegpt', async (req, res) => {
    try {
      const { text } = req.query

      if (!text) {
        return res.status(400).json({
          status: false,
          error: 'Falta parámetro: text'
        })
      }

      const ai = new NoteGPTChat()
      const response = await ai.chat(text)

      res.json({
        status: true,
        result: response
      })

    } catch (e) {
      res.status(500).json({
        status: false,
        error: e.message
      })
    }
  })
}