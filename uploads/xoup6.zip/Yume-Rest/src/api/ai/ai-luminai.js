const { OpenAI } = require("openai");

module.exports = function(app) {

    // Inicializa el cliente con tu API Key
    const openai = new OpenAI({
        apiKey: "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"
    });

    app.get('/ai/luminai', async (req, res) => {
        try {
            const { text } = req.query;
            if (!text) {
                return res.status(400).json({ status: false, error: 'Text is required' });
            }

            // Llamada al modelo ChatGPT
            const completion = await openai.chat.completions.create({
                model: "gpt-3.5-turbo",
                messages: [
                    { role: "system", content: "You are a helpful AI assistant." },
                    { role: "user", content: text }
                ],
                max_tokens: 500,
                temperature: 0.7
            });

            const result = completion.choices[0].message.content;

            res.status(200).json({
                status: true,
                result
            });

        } catch (error) {
            console.error("OpenAI Error:", error);
            res.status(500).json({ status: false, error: error.message });
        }
    });

};