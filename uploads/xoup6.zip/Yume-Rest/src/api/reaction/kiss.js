const axios = require("axios");

const API_KEY = "yume.chan";

async function getGifUrl(type) {
  try {
    try {
      const apiRes = await axios.get(
        `https://nekos.best/api/v2/${type}`,
        { timeout: 10000 }
      );
      const url = apiRes.data?.results?.[0]?.url;
      if (url) return url;
    } catch (e) {}

    const waifuRes = await axios.get(
      `https://api.waifu.pics/sfw/${type}`,
      { timeout: 10000 }
    );
    const url = waifuRes.data?.url;
    if (url) return url;

    throw new Error("GIF no disponible");
  } catch (error) {
    throw new Error("GIF no disponible");
  }
}

async function sendGif(type, res) {
  try {
    const gifUrl = await getGifUrl(type);
    
    const gifResponse = await axios.get(gifUrl, {
      responseType: "arraybuffer",
      timeout: 20000
    });

    res.set({
      "Content-Type": "image/gif",
      "Content-Length": gifResponse.data.length,
      "Cache-Control": "public, max-age=0"
    });

    res.end(Buffer.from(gifResponse.data));
  } catch (e) {
    res.status(500).json({ status: false, error: e.message });
  }
}

module.exports = function(app) {

  app.get("/reaction/lurk", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("lurk", res);
  });

  app.get("/reaction/shoot", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("shoot", res);
  });

  app.get("/reaction/sleep", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("sleep", res);
  });

  app.get("/reaction/shrug", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("shrug", res);
  });

  app.get("/reaction/stare", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("stare", res);
  });

  app.get("/reaction/wave", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("wave", res);
  });

  app.get("/reaction/poke", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("poke", res);
  });

  app.get("/reaction/smile", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("smile", res);
  });

  app.get("/reaction/peck", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("peck", res);
  });

  app.get("/reaction/wink", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("wink", res);
  });

  app.get("/reaction/blush", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("blush", res);
  });

  app.get("/reaction/smug", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("smug", res);
  });

  app.get("/reaction/tickle", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("tickle", res);
  });

  app.get("/reaction/yeet", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("yeet", res);
  });

  app.get("/reaction/think", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("think", res);
  });

  app.get("/reaction/highfive", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("highfive", res);
  });

  app.get("/reaction/feed", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("feed", res);
  });

  app.get("/reaction/bite", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("bite", res);
  });

  app.get("/reaction/bored", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("bored", res);
  });

  app.get("/reaction/nom", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("nom", res);
  });

  app.get("/reaction/yawn", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("yawn", res);
  });

  app.get("/reaction/facepalm", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("facepalm", res);
  });

  app.get("/reaction/cuddle", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("cuddle", res);
  });

  app.get("/reaction/kick", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("kick", res);
  });

  app.get("/reaction/happy", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("happy", res);
  });

  app.get("/reaction/hug", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("hug", res);
  });

  app.get("/reaction/baka", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("baka", res);
  });

  app.get("/reaction/bonk", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("bonk", res);
  });

  app.get("/reaction/pat", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("pat", res);
  });

  app.get("/reaction/angry", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("angry", res);
  });

  app.get("/reaction/run", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("run", res);
  });

  app.get("/reaction/nod", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("nod", res);
  });

  app.get("/reaction/nope", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("nope", res);
  });

  app.get("/reaction/kiss", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("kiss", res);
  });

  app.get("/reaction/dance", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("dance", res);
  });

  app.get("/reaction/punch", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("punch", res);
  });

  app.get("/reaction/handshake", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("handshake", res);
  });

  app.get("/reaction/slap", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("slap", res);
  });

  app.get("/reaction/cry", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("cry", res);
  });

  app.get("/reaction/pout", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("pout", res);
  });

  app.get("/reaction/handhold", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("handhold", res);
  });

  app.get("/reaction/thumbsup", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("thumbsup", res);
  });

  app.get("/reaction/laugh", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("laugh", res);
  });

  app.get("/reaction/tableflip", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("tableflip", res);
  });

  app.get("/reaction/bully", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("bully", res);
  });

  app.get("/reaction/lick", async (req, res) => {
    if (req.query.key !== API_KEY)
      return res.status(403).json({ status: false, error: "API key inválida" });
    sendGif("lick", res);
  });

};