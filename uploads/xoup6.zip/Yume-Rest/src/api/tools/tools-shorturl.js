const crypto = require('crypto')
const fetch = require('node-fetch')

const owner = 'Dev-lxyz'
const repo = 'upload'
const filePath = 'upload/links.json'
const token = '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'

module.exports = function (app) {
  let urlMap = {}

  async function loadLinks() {
    try {
      const res = await fetch(`https://api.github.com/repos/${owner}/${repo}/contents/${filePath}`, {
        headers: { Authorization: `token ${token}` }
      })
      const data = await res.json()
      const content = Buffer.from(data.content, 'base64').toString()
      urlMap = JSON.parse(content)
    } catch (e) {
      console.error('No se pudo cargar links.json:', e.message)
      urlMap = {}
    }
  }

  async function saveLinks() {
    try {
      const res = await fetch(`https://api.github.com/repos/${owner}/${repo}/contents/${filePath}`, {
        headers: { Authorization: `token ${token}` }
      })
      const data = await res.json()

      await fetch(`https://api.github.com/repos/${owner}/${repo}/contents/${filePath}`, {
        method: 'PUT',
        headers: {
          Authorization: `token ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: 'update links.json',
          content: Buffer.from(JSON.stringify(urlMap, null, 2)).toString('base64'),
          sha: data.sha
        })
      })
    } catch (e) {
      console.error('Error guardando links.json:', e.message)
    }
  }

  (async () => { await loadLinks() })()

  app.get('/tools/shorturl', async (req, res) => {
    try {
      const { url } = req.query
      if (!url || !/^https?:\/\//.test(url)) {
        return res.status(400).json({ status: false, error: 'URL inválida' })
      }

      const hash = crypto.createHash('md5').update(url).digest('hex').slice(0, 6)
      urlMap[hash] = url
      await saveLinks()

      const domain = req.headers.host
      res.json({
        status: true,
        data: {
          link: `https://${domain}/l/${hash}`,
          original_url: url
        }
      })
    } catch (e) {
      res.status(500).json({ status: false, error: e.message })
    }
  })

  app.get('/l/:hash', (req, res) => {
    const { hash } = req.params
    const target = urlMap[hash]
    if (!target) return res.status(404).send('URL no encontrada')
    res.redirect(target)
  })
}