const axios = require('axios')

module.exports = function (app) {

  app.get('/tools/whatmusic', async (req, res) => {
    try {
      const { url } = req.query

      if (!url)
        return res.status(400).json({
          status: false,
          message: 'Falta el parámetro url (audio)'
        })

      const apiKey = '10c279a611db9833a9dd4c2195293bfc'

      const { data } = await axios.post(
        'https://api.audd.io/',
        new URLSearchParams({
          api_token: apiKey,
          url,
          return: 'apple_music,spotify,youtube'
        }).toString(),
        {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          timeout: 20000
        }
      )

      if (!data.result)
        return res.json({
          status: false,
          message: 'No se pudo reconocer la música'
        })

      const r = data.result

      res.json({
        status: true,
        result: {
          title: r.title,
          artist: r.artist,
          album: r.album,
          release_date: r.release_date,
          duration: r.duration,
          label: r.label,
          timecode: r.timecode,

          cover:
            r.spotify?.album?.images?.[0]?.url ||
            r.apple_music?.artwork?.url?.replace('{w}x{h}', '500x500') ||
            null,

          links: {
            song_link: r.song_link || null,

            youtube:
              r.youtube?.url ||
              r.links?.youtube ||
              (r.title && r.artist
                ? `https://www.youtube.com/results?search_query=${encodeURIComponent(
                    `${r.title} ${r.artist}`
                  )}`
                : null),

            spotify: r.spotify?.external_urls?.spotify || null,
            apple_music: r.apple_music?.url || null
          },

          spotify: r.spotify
            ? {
                track: r.spotify.external_urls.spotify,
                artist: r.spotify.artists?.[0]?.external_urls?.spotify,
                album: r.spotify.album?.external_urls?.spotify
              }
            : null,

          apple_music: r.apple_music
            ? {
                track: r.apple_music.url,
                preview: r.apple_music.previews?.[0]?.url || null
              }
            : null
        },

        inspected_at: new Date().toISOString()
      })

    } catch (err) {
      res.status(500).json({
        status: false,
        error: err.message
      })
    }
  })

}