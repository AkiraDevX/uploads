const express = require('express')
const fetch = require('node-fetch')
const FormData = require('form-data')

const ALLOWED_SCALES = ["2", "4", "8", "16"]

module.exports = function(app) {

  app.get('/tools/hd', async (req, res) => {
    try {
      const { url, scale = "2" } = req.query

      if (!url || !/^https?:\/\/.+\.(jpg|jpeg|png)$/i.test(url)) {
        return res.status(400).json({
          status: false,
          error: "URL de imagen inválida"
        })
      }

      if (!ALLOWED_SCALES.includes(String(scale))) {
        return res.status(400).json({
          status: false,
          error: `Scale inválido (solo ${ALLOWED_SCALES.join(', ')})`
        })
      }

      // 1️⃣ Descargar imagen
      const imgResp = await fetch(url)
      if (!imgResp.ok) throw new Error("No se pudo descargar la imagen")
      const imgBuffer = await imgResp.buffer()
      const mimeType = imgResp.headers.get("content-type") || "image/jpeg"

      // 2️⃣ Subir a Pixelcut
      const form = new FormData()
      form.append('image', imgBuffer, { filename: `upscaled.${mimeType.split('/')[1]}`, contentType: mimeType })
      form.append('scale', scale)

      const headers = {
        ...form.getHeaders(),
        accept: "application/json",
        "x-client-version": "web",
        "x-locale": "en"
      }

      const pixelcutRes = await fetch("https://api2.pixelcut.app/image/upscale/v1", {
        method: "POST",
        headers,
        body: form
      })

      const json = await pixelcutRes.json()
      if (!json?.result_url || !json.result_url.startsWith("http")) {
        throw new Error("No se obtuvo result_url de Pixelcut")
      }

      // 3️⃣ Opcional: Convertir a base64 si quieres
      const resultBuffer = await (await fetch(json.result_url)).buffer()
      const base64 = resultBuffer.toString("base64")

      // 4️⃣ Responder
      return res.json({
        status: true,
        data: {
          scale: `${scale}x`,
          original_url: url,
          upscaled_url: json.result_url,
          image_base64: `data:${mimeType};base64,${base64}`
        },
        timestamp: Date.now()
      })

    } catch (err) {
      console.error("[HD-ENDPOINT]", err.message)
      return res.status(500).json({
        status: false,
        error: err.message
      })
    }
  })

}