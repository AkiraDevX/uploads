const express = require('express')          // Framework HTTP
const chalk = require('chalk')              // Colores en consola
const fs = require('fs')                    // Sistema de archivos
const cors = require('cors')                // CORS
const path = require('path')                // Manejo de rutas
const os = require('os')
const si = require('systeminformation')     // Info avanzada del sistema
const axios = require('axios')              // Requests HTTP

require('./clear.js')

const app = express()
const PORT = process.env.PORT || 3000

const uploadDir = path.join(process.cwd(), "files")

// Crear carpeta files si no existe
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir)
}

// Servir archivos estáticos
app.use("/files", express.static(uploadDir))

// =====================
// EXPRESS SETTINGS
// =====================
app.enable("trust proxy")                   // Para usar IP real
app.set("json spaces", 2)                   // JSON bonito
app.use(express.json())                     // JSON body
app.use(express.urlencoded({ extended: false }))
app.use(cors())                             // Habilita CORS

// Archivos estáticos
app.use('/', express.static(path.join(__dirname, 'public')))
app.use('/src', express.static(path.join(__dirname, 'src')))

// =====================
// SETTINGS.JSON
// =====================
const settingsPath = path.join(__dirname, './src/settings.json')
const settings = JSON.parse(fs.readFileSync(settingsPath, 'utf-8'))

// =====================
// CONTADORES
// =====================
let requestCount = 0                        // Requests totales
const apiStartTime = Date.now()             // Inicio de la API
const userRequests = {}                    // Requests por IP

// =====================
// FORMATEAR UPTIME
// =====================
function formatUptime(seconds) {
  const d = Math.floor(seconds / 86400)
  seconds %= 86400
  const h = Math.floor(seconds / 3600)
  seconds %= 3600
  const m = Math.floor(seconds / 60)
  const s = Math.floor(seconds % 60)

  return `${d}D, ${h}H, ${m}M, ${s}S`
}

// =====================
// RATE LIMIT POR IP
// =====================
app.use((req, res, next) => {
  const ip =
    req.headers['x-forwarded-for']?.split(',')[0] ||
    req.socket.remoteAddress ||
    'unknown'

  const currentDate = new Date().toISOString().split('T')[0]

  if (!userRequests[ip]) userRequests[ip] = {}

  if (userRequests[ip].date !== currentDate) {
    userRequests[ip].date = currentDate
    userRequests[ip].count = 0
  }

  if (userRequests[ip].count >= parseInt(settings.apiSettings.limit)) {
    return res.status(429).json({
      status: 429,
      message: "Daily request limit reached",
      creator: settings.apiSettings.creator
    })
  }

  userRequests[ip].count++
  requestCount++
  next()
})

// =====================
// INYECTAR CREATOR
// =====================

app.use((req, res, next) => {
  const originalJson = res.json

  res.json = function (data) {
    if (data && typeof data === 'object') {
      return originalJson.call(this, {
        status: data.status,
        creator: settings.apiSettings.creator || "xd",
        ...data
      })
    }
    return originalJson.call(this, data)
  }

  next()
})

// =====================
// CARGAR RUTAS DINÁMICAS
// =====================
let totalRoutes = 0
const apiFolder = path.join(__dirname, './src/api')

fs.readdirSync(apiFolder).forEach(folder => {
  const folderPath = path.join(apiFolder, folder)

  if (fs.statSync(folderPath).isDirectory()) {
    fs.readdirSync(folderPath).forEach(file => {
      if (path.extname(file) === '.js') {
        require(path.join(folderPath, file))(app)
        totalRoutes++
        console.log(
          chalk.bgHex('#FFFF99').hex('#333').bold(` Loaded Route: ${file} `)
        )
      }
    })
  }
})

console.log(chalk.bgHex('#90EE90').hex('#333').bold(' Load Complete! ✓ '))
console.log(
  chalk.bgHex('#90EE90').hex('#333').bold(` Total Routes Loaded: ${totalRoutes} `)
)

// =====================
// STATUS ENDPOINT (MEJORADO)
// =====================
app.get('/status-page', async (req, res) => {
  const start = Date.now()

  const ip =
    req.headers['x-forwarded-for']?.split(',')[0] ||
    req.socket.remoteAddress ||
    'unknown'

  const uptimeSeconds = Math.floor((Date.now() - apiStartTime) / 1000)
  const uptimeFormatted = formatUptime(uptimeSeconds)

  let geo = {}
  try {
    const geoRes = await axios.get(`https://ipapi.co/${ip}/json/`)
    geo = geoRes.data
  } catch {
    geo = { error: true }
  }

  const mem = await si.mem()
  const cpu = await si.cpu()
  const cpuSpeed = await si.cpuCurrentSpeed()
  const cpuTemp = await si.cpuTemperature()
  const disk = await si.fsSize()
  const osInfo = await si.osInfo()
  const net = await si.networkInterfaces()
  const processes = await si.processes()

  const latency = Date.now() - start

  res.json({
    creator: settings.apiSettings.creator,
    uptime: uptimeFormatted,
    total_requests: requestCount,
    routes_loaded: totalRoutes,
    daily_limit: settings.apiSettings.limit,
    active_users: Object.keys(userRequests).length,
    current_date: new Date().toISOString(),
    api_latency_ms: latency,
    user: {
      ip: ip,
      geo: {
        country: geo.country_name || 'Unknown',
        region: geo.region || 'Unknown',
        city: geo.city || 'Unknown',
        timezone: geo.timezone || 'Unknown',
        latitude: geo.latitude || null,
        longitude: geo.longitude || null,
        isp: geo.org || 'Unknown'
      }
    },
    system: {
      hostname: os.hostname(),
      platform: os.platform(),
      arch: os.arch(),
      os_distro: osInfo.distro,
      release: osInfo.release,
      uptime_os_seconds: os.uptime(),
      cpu_model: cpu.brand,
      cores: cpu.cores,
      cpu_speed_ghz: cpuSpeed.avg,
      cpu_temperature_celsius: cpuTemp.main || 'N/A',
      ram_total_gb: (mem.total / 1e9).toFixed(2),
      ram_used_gb: ((mem.total - mem.available) / 1e9).toFixed(2),
      ram_free_gb: (mem.available / 1e9).toFixed(2),
      disk_total_gb: (disk[0]?.size / 1e9).toFixed(2),
      disk_used_gb: (disk[0]?.used / 1e9).toFixed(2),
      disk_free_gb: (disk[0]?.available / 1e9).toFixed(2),
      cpu_load_percent: cpuSpeed.avg ? cpuSpeed.avg * 10 : 'Unknown',
      running_processes: processes.all,
      network_interfaces: net.map(n => ({
        iface: n.iface,
        ip4: n.ip4,
        mac: n.mac,
        speed: n.speed
      }))
    }
  })
})

// =====================
// PAGINAS
// =====================
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'))
})

app.get('/docs', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'docs.html'))
})

app.get('/status', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'status.html'))
})

// =====================
// ERRORES
// =====================
app.use((req, res) => {
  res.status(404).sendFile(process.cwd() + "/public/404.html")
})

app.use((err, req, res, next) => {
  console.error(err.stack)
  res.status(500).sendFile(process.cwd() + "/public/500.html")
})

// =====================
// START SERVER
// =====================
app.listen(PORT, () => {
  console.log(
    chalk.bgHex('#90EE90').hex('#333').bold(` Server running on port ${PORT} `)
  )
})

module.exports = app

