const fs = require('fs')
const path = require('path')

// Ruta correcta a la carpeta ./files
const filesDir = path.resolve('./files')

// Crear carpeta si no existe
if (!fs.existsSync(filesDir)) {
  fs.mkdirSync(filesDir)
  console.log('[Cleaner] Carpeta ./files creada')
}

console.log('[Cleaner] Limpieza de ./files activada (cada 5 minutos)')
console.log('[Cleaner] Ruta real:', filesDir)

setInterval(async () => {
  try {
    const files = await fs.promises.readdir(filesDir)

    for (const file of files) {
      const filePath = path.join(filesDir, file)
      await fs.promises.unlink(filePath).catch(() => {})
    }

    if (files.length > 0) {
      console.log(`[Cleaner] ${files.length} archivos eliminados`)
    }
  } catch (err) {
    console.error('[Cleaner] Error:', err.message)
  }
}, 5 * 60 * 1000) // 5 minutos