import express from "express";
import axios from "axios";

const router = express.Router();

// Endpoint: /apksearch?q=Whatsapp
router.get("/download/apk", async (req, res) => {
  try {
    const query = req.query.q;
    if (!query) return res.status(400).json({ error: "Falta query" });

    const apiURL = `https://api.delirius.store/download/apk?query=${encodeURIComponent(query)}`;

    const { data } = await axios.get(apiURL);

    if (!data.status || !data.data) {
      return res.status(404).json({ error: "No se encontró la app" });
    }

    const d = data.data;

    // 🔥 Keys personalizadas (distintas de las originales)
    const result = {
      appName: d.name,
      packageId: d.id,
      lastUpdate: d.publish,
      fileSize: d.size,
      bytes: d.sizeByte,
      icon: d.image,
      downloadUrl: d.download,
      developer: d.developer,
      storeInfo: {
        storeName: d.store.name,
        storeAvatar: d.store.avatar
      },
      statistics: {
        downloads: d.stats.downloads,
        ratingAverage: d.stats.rating.average,
        ratingCount: d.stats.rating.total
      }
    };

    res.json({
      ok: true,
      result
    });

  } catch (error) {
    res.status(500).json({
      ok: false,
      error: "Error procesando la solicitud"
    });
  }
});

export default router;